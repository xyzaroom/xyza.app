import { ArrowRight, Music } from "lucide-react"

export function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-card to-background">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-block px-4 py-2 bg-primary/10 border border-primary/20 rounded-full">
                <span className="text-primary text-sm font-semibold">Digital Music Distribution</span>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Distribute Your Music <span className="text-primary">Globally</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg">
                Get your tracks on all major streaming platforms instantly. Xyzaroom Records makes music distribution
                simple, fast, and affordable for independent artists.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition flex items-center justify-center gap-2">
                Start Distributing <ArrowRight size={20} />
              </button>
              <button className="px-8 py-3 border border-border text-foreground rounded-lg font-semibold hover:bg-card transition">
                Learn More
              </button>
            </div>

            <div className="flex gap-8 pt-4">
              <div>
                <p className="text-2xl font-bold text-primary">50K+</p>
                <p className="text-muted-foreground">Artists Distributed</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">1B+</p>
                <p className="text-muted-foreground">Streams Generated</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">150+</p>
                <p className="text-muted-foreground">Platforms Covered</p>
              </div>
            </div>
          </div>

          <div className="relative h-96 md:h-full min-h-96">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent rounded-2xl blur-3xl" />
            <div className="relative h-full bg-card border border-border rounded-2xl flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 400 400">
                  <circle cx="200" cy="200" r="150" fill="none" stroke="currentColor" strokeWidth="1" />
                  <circle cx="200" cy="200" r="100" fill="none" stroke="currentColor" strokeWidth="1" />
                  <circle cx="200" cy="200" r="50" fill="none" stroke="currentColor" strokeWidth="1" />
                </svg>
              </div>
              <Music size={120} className="text-primary/40" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
