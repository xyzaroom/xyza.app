"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">X</span>
          </div>
          <span className="text-xl font-bold text-foreground">Xyzaroom</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-muted-foreground hover:text-foreground transition">
            Features
          </a>
          <a href="#process" className="text-muted-foreground hover:text-foreground transition">
            How It Works
          </a>
          <a href="#artists" className="text-muted-foreground hover:text-foreground transition">
            For Artists
          </a>
          <a href="#contact" className="text-muted-foreground hover:text-foreground transition">
            Contact
          </a>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <button className="px-6 py-2 text-foreground hover:text-primary transition">Sign In</button>
          <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition">
            Get Started
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-card border-b border-border">
          <div className="px-4 py-4 space-y-4">
            <a href="#features" className="block text-muted-foreground hover:text-foreground">
              Features
            </a>
            <a href="#process" className="block text-muted-foreground hover:text-foreground">
              How It Works
            </a>
            <a href="#artists" className="block text-muted-foreground hover:text-foreground">
              For Artists
            </a>
            <a href="#contact" className="block text-muted-foreground hover:text-foreground">
              Contact
            </a>
            <button className="w-full px-6 py-2 bg-primary text-primary-foreground rounded-lg">Get Started</button>
          </div>
        </div>
      )}
    </header>
  )
}
