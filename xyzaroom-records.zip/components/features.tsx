import { Music, Globe, Zap, BarChart3, Lock, Users } from "lucide-react"

const features = [
  {
    icon: Music,
    title: "Multi-Format Support",
    description: "Upload MP3, WAV, FLAC, and more. We handle all formats automatically.",
  },
  {
    icon: Globe,
    title: "Global Distribution",
    description: "Reach listeners on Spotify, Apple Music, YouTube, and 150+ platforms.",
  },
  {
    icon: Zap,
    title: "Instant Publishing",
    description: "Your music goes live within 24-48 hours across all platforms.",
  },
  {
    icon: BarChart3,
    title: "Real-Time Analytics",
    description: "Track streams, revenue, and listener demographics in real-time.",
  },
  {
    icon: Lock,
    title: "Rights Protection",
    description: "Automatic copyright registration and royalty management included.",
  },
  {
    icon: Users,
    title: "Artist Support",
    description: "24/7 support team ready to help with any questions or issues.",
  },
]

export function Features() {
  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Everything You Need</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Powerful tools designed specifically for independent musicians and labels
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div
                key={index}
                className="p-8 bg-card border border-border rounded-xl hover:border-primary/50 transition group"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition">
                  <Icon className="text-primary" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
