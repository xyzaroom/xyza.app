import { CheckCircle2 } from "lucide-react"

const steps = [
  {
    number: "01",
    title: "Create Account",
    description: "Sign up and verify your artist profile in minutes",
  },
  {
    number: "02",
    title: "Upload Music",
    description: "Add your tracks with metadata, artwork, and release details",
  },
  {
    number: "03",
    title: "Set Release Date",
    description: "Choose when your music goes live across all platforms",
  },
  {
    number: "04",
    title: "Earn Royalties",
    description: "Receive payments directly as your music streams worldwide",
  },
]

export function Process() {
  return (
    <section id="process" className="py-20 px-4 sm:px-6 lg:px-8 bg-card">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Simple Process</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            From upload to global distribution in just 4 easy steps
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-background border border-border rounded-xl p-8 text-center">
                <div className="text-5xl font-bold text-primary/20 mb-4">{step.number}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-muted-foreground text-sm">{step.description}</p>
              </div>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <CheckCircle2 size={20} className="text-primary-foreground" />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
