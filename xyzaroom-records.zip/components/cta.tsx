import { ArrowRight } from "lucide-react"

export function CTA() {
  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-card">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
          Ready to Share Your Music with the World?
        </h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Join Xyzaroom Records today and start distributing your music to millions of listeners globally.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition flex items-center justify-center gap-2">
            Get Started Free <ArrowRight size={20} />
          </button>
          <button className="px-8 py-4 border border-border text-foreground rounded-lg font-semibold hover:bg-background transition">
            Schedule Demo
          </button>
        </div>

        <p className="text-muted-foreground text-sm mt-8">No credit card required. Start distributing in minutes.</p>
      </div>
    </section>
  )
}
