import { Star } from "lucide-react"

const artists = [
  {
    name: "Luna Echo",
    genre: "Electronic",
    streams: "2.5M",
    image: "/female-artist-electronic-music.jpg",
  },
  {
    name: "Sonic Wave",
    genre: "Hip-Hop",
    streams: "5.8M",
    image: "/male-artist-hip-hop-music.jpg",
  },
  {
    name: "Indie Vibes",
    genre: "Indie Pop",
    streams: "3.2M",
    image: "/artist-indie-pop-music.jpg",
  },
]

export function Artists() {
  return (
    <section id="artists" className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Featured Artists</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join thousands of successful independent artists on Xyzaroom Records
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {artists.map((artist, index) => (
            <div key={index} className="group">
              <div className="relative mb-6 overflow-hidden rounded-xl">
                <img
                  src={artist.image || "/placeholder.svg"}
                  alt={artist.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-sm text-primary font-semibold">{artist.genre}</p>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-1">{artist.name}</h3>
              <p className="text-muted-foreground mb-4">{artist.streams} streams</p>
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-primary text-primary" />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
